<footer>
        <div class="footer">
            <div class="footer1 img">
                <div class="img">
                <img src="assets/images/facebook.png">
                </div>
                <div class="img">
                    <img src="assets/images/googleplus.png">
                </div>
                <div class="img">
                    <img src="assets/images/linkedin.png">
                </div>
                <div class="img">
                    <img src="assets/images/pinterest.png">
                </div>
                <div class="img">
                <img src="assets/images/twitter.png">
                </div>
            </div>
            <div class="footer1">
                <h3>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                </h3>
            </div>
                <div class="footer1 input">
                <input type="email" placeholder="SEU E-MAIL"><BR>
                <a href="" class="button">INSCREVER-SE</a>
            </div>
        </div>
    </footer>